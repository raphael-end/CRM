
<?php $__env->startSection('conteudo'); ?>
<main class="h-full pb-16 overflow-y-auto">
  <div class="container px-6 mx-auto grid">

    <!-- CTA -->
    <a style="background-color: #002859;" class="flex items-center w-2/5 p-4 mb-8 text-sm font-semibold mt-10 text-purple-100  rounded-lg shadow-md focus:outline-none focus:shadow-outline-purple">


      <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
      </svg>
      <h2 class="my-6 text-2xl font-semibold text-gray-100 dark:text-gray-200">
        CADASTRO DE VENDAS
      </h2>


    </a>

    <div class="px-4 py-3 mb-8 w-2/5 bg-white rounded-lg shadow-md dark:bg-gray-800">
      <form action="<?php echo e(route ("admin.storeTarefas")); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label class="flex flex-row items-center mt-4 text-sm">
          <span class="text-gray-700 text-xl dark:text-gray-400">
            Tipo:
          </span>
          <select name="estado" id="select-state" class="ml-5 border border-gray-300 p-3 rounded-lg">

            <option value="venda">venda</option>
            <option value="reparo">reparo</option>

          </select>
        </label>

        <label class="flex flex-row items-center mt-5  text-sm">
          <span class="text-gray-700 text-xl dark:text-gray-400">
          Nome cliente:
          </span>
          <select name="id_cliente" id="select-state" class="ml-5 border border-gray-300 p-3 rounded-lg">
            <?php $__currentLoopData = $data['cliente']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option  value="<?php echo e($datas->id); ?>"><?php echo e($datas->nome); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </label>

        <label class="flex flex-row items-center mt-4 text-sm">
          <span class="text-gray-700 text-xl dark:text-gray-400">
            Valor:
          </span>
          <input name="valorRep" class="ml-5 border border-gray-300 p-3 rounded-lg" placeholder="Ex: R$ 220.00" />
        </label>
        <label class="flex flex-row items-center mt-4 text-sm">
          <span class="text-gray-700 text-xl dark:text-gray-400">
            Custo:
          </span>
          <input name="custoRep" class="ml-5 border border-gray-300 p-3 rounded-lg" placeholder="Ex: R$ 120.00" />
        </label>

        <label class="flex flex-row items-center mt-4 text-sm">
          <span class="text-gray-700 text-xl dark:text-gray-400">
            Objetos usados:
          </span>

          <select id="produtos" name="produtos" class="ml-5 border border-gray-300 p-3 rounded-lg">
            <?php $__currentLoopData = $data["produtos"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($produto->nome); ?>"><?php echo e($produto->nome); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>

        </label>

        <label class="flex flex-row items-center mt-4 text-sm">
          <span class="text-gray-700 text-xl dark:text-gray-400">Data do agendamento:</span>
          <input  class="ml-5 border border-gray-300 p-3 rounded-lg" type="date" placeholder="data" name="date">
        </label>

        <div class="flex items-center mt-5 justify-center bg-grey-lighter">
          <label class="w-64 flex flex-col items-center px-4 py-6 bg-white text-blue rounded-lg shadow-lg tracking-wide uppercase border border-blue cursor-pointer hover:bg-blue-900
 hover:text-white">
            <svg class="w-8 h-8" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
              <path d="M16.88 9.1A4 4 0 0 1 16 17H5a5 5 0 0 1-1-9.9V7a3 3 0 0 1 4.52-2.59A4.98 4.98 0 0 1 17 8c0 .38-.04.74-.12 1.1zM11 11h3l-4-4-4 4h3v3h2v-3z" />
            </svg>
            <span class="mt-2 text-base leading-normal">Selecione o documento de confirmação</span>
            <input type="file" name="arquivo" class="hidden" />
          </label>
        </div>
        <div>
          <button type="submit" style="background-color: #002859;"  class="px-10 mt-5 py-4 w-full font-medium leading-5 text-white transition-colors duration-150   border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple">
            Cadastrar
          </button>
        </div>
    </div>                
    </form>

  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.templateProduto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/cadvendas.blade.php ENDPATH**/ ?>